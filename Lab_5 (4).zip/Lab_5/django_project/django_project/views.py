from django.http import JsonResponse

def project(request):

    data = {"Message": "Hello World!"}

    return JsonResponse(data, safe=False)




